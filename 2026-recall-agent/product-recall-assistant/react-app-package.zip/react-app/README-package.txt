Product Recall Assistant - Lab 8 packaged app

Requirements: Node.js 20+ and npm. Complete the Lab 8 database setup first.

1. Install dependencies: npm ci
2. Create your local config: cp .env.example .env
3. Edit .env with your ADB TLS connect string or wallet TNS alias and wallet settings.
4. Start the app: npm start
5. Open http://localhost:3001

The production React UI and Node API are served together. Keep .env private; it is not included in this archive.
For wallet connections set ORACLE_CONFIG_DIR and/or ORACLE_WALLET_LOCATION to the absolute wallet directory, and set ORACLE_WALLET_PASSWORD.
